clc;
clear all;
close all;

x=linspace(-2,2,100);
f=0;
k=0;

%Semnalul 5
X=[-2,-1,0,1,2];
Y=[-1,-1,0,1,1];

figure(1)

for n=1:1:20
  
  bn=2/(n*pi)*(-(-1)^n+2/(pi*n)*sin((pi*n)/2));%coeficientul bn al sumei Fourier de la pasul curent
  f=f+bn*sin(n*pi*x/2);%suma partiala Fourier de la pasul curent
  
  if(n==2 || n==7 || n==4 || n==10)
  k=k+1;
  subplot(2,2,k), line(X,Y,'color','r')
  hold on;
  subplot(2,2,k), plot(x,f,'k');%generare subgrafic
  title(['n = ', num2str(n)]), grid
  endif;

endfor
