%c
f=0;
c=0;
figure(2);
for n=1:1:20
  f=f-((20*(-1)^n/(n*pi))*sin((n*pi*x)/10)); %suma fourier calculata 
  s=10*sawtooth(2*pi*0.05*(semnal-10));
  error=mean((abs(f)-abs(s)).^2);
  if(n==2||n==4||n==7||n==10)
  c=c+1;
  
  subplot(2,2,c), plot(semnal,s,'color','r','linewidth',2) %generare subgrafic
  hold on; %afisare grafic peste grafic
  subplot(2,2,c), plot(semnal,f,'c','linewidth',2),
  title(['n=',num2str(n), 'Eroare=',num2str(error)]),grid
  endif
endfor