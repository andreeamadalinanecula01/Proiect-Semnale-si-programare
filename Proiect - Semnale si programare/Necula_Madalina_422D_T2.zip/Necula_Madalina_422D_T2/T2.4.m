clc;
clear all;
close all;


x=linspace(0,3,100);
f=2/3;
k=0;

%Semnalul 4
X=[0,1,2,3];
Y=[0,1,1,0];
figure(1);

for n=1:1:100
  
 
  f=f+(6/(n^2*pi^2)*(cos(n*pi/3)-1-(-1)^n+cos(2*n*pi/3))*cos(n*pi*x/3));%suma partiala Fourier de la pasul curent
  
  if(n==2 || n==4 || n==7 || n==10)
  k=k+1;
  subplot(2,2,k), line(X,Y,'color','r')
  hold on;
  subplot(2,2,k), plot(x,f,'k');%generare subgrafic
  title(['n = ', num2str(n)]), grid
  endif;

endfor