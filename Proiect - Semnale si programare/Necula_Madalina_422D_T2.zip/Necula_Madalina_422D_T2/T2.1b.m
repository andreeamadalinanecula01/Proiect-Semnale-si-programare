clc;
clear all;
close all;
x=linspace(-10,10,2000);
f=0;
c=0;

function y=rampa(x)
  y=x;
end
semnal=rampa(x);

%b
figure(1);
for n=1:1:16
  f=f-((20*(-1)^n/(n*pi))*sin((n*pi*x)/10)); %suma fourier calculata 
  s=10*sawtooth(2*pi*0.05*(semnal-10));
  error=mean((abs(f)-abs(s)).^2);
  c=c+1;
  subplot(4,4,c), plot(semnal,s,'color','r','linewidth',2); %generare subgrafic
  hold on; %afisare grafic peste grafic
  subplot(4,4,c), plot(semnal,f,'c','linewidth',2);
  title(['n=',num2str(n), 'Eroare=',num2str(error)]),grid
end