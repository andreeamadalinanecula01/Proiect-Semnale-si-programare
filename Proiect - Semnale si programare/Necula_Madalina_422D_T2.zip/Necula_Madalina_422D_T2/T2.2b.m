clc;
clear all;
close all;
x=linspace(-30,30,2000);
f=2/pi;
c=1;

%b
figure(1);
for n=1:1:12  %deseneaza 12 grafice
  c=c+1;
  s=abs(sin(pi*x/10));
  f=f-(2*((-1)^c+2))/(pi*(c^2-1))*cos((c*pi*x)/10); %suma fourier calculata 

  error=mean((abs(f)-abs(s)).^2);
  
  subplot(4,3,c-1), plot(x,s,'color','r','linewidth',2) %generare subgrafic
  hold on; %afisare grafic peste grafic
  subplot(4,3,c-1), plot(x,f,'c','linewidth',2),
  title(['n=',num2str(n), 'Eroare=',num2str(error)]),grid
end
