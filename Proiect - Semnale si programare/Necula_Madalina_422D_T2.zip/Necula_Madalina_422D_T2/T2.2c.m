%c
clc;
clear all;
x=linspace(-30,30,2000);
f=2/pi;
c=1; n=0;
g=0; %reprezinta nr graficului
figure(2);
for n=1:1:10
  c=c+1;
  s=abs(sin(pi*x/10))
   f=f-(2*((-1)^c+1))/(pi*(c^2-1))*cos((c*pi*x)/10);%suma fourier calculata 
  
  error=mean((abs(f)-abs(s)).^2);
  if((n==2)||(n==4)||(n==7)||(n==10))
  g=g+1;
  
  subplot(2,2,g), plot(x,s,'color','r','linewidth',2); %generare subgrafic
  hold on; %afisare grafic peste grafic
  subplot(2,2,g), plot(x,f,'c','linewidth',2);
  title(['n=',num2str(n), 'Eroare=',num2str(error)]),grid
  endif
end
