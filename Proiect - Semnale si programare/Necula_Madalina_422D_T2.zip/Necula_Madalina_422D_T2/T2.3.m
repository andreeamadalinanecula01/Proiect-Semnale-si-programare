clear all;
clc;
close all;

x=linspace(-10,10,100);
f=1/pi;
k=0;

%semnal redresat monoalternanta

for n=1:1:20
  
  f=f-((2*cos(n*pi/2)/pi*(n^2-1))*cos(n*pi*x/10));%suma partiala Fourier de la pasul curent
  
  if(n==2 || n==4 || n==7 || n==10) 
  k=k+1;
  subplot(2,2,k)
  hold on;
  subplot(2,2,k), plot(x,f,'k')%generare subgrafic
  grid
  title(['n= ', num2str(n)])
  endif

endfor