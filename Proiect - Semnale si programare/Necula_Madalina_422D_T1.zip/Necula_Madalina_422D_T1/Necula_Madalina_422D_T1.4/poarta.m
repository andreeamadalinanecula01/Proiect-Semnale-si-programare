%% definirea functiei poarta in fisierul poarta.m
function[x]= poarta(t)
  %t variabila pentru care apelam functia
  % x rezultatul functiei conform relatiei de mai sus
  %pentru a evalua functia rulati in Command window poarta(4),sau 
  %poarta([1,3,4]),etc
  if(abs(t)<0.5)
    x = 1;
  else
    x = 0;
  endif  % returneaza 1 daca relatia este adevarata si 0
                % daca relatia este falsa