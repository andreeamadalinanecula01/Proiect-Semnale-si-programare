%% definirea functiei rampa in fisierul rampa.m
function[x]= rampa(t)
  %t variabila pentru care apelam functia
  % x rezultatul functiei conform relatiei de mai sus
  %pentru a evalua functia rulati in Command window rampa(4),sau 
  %rampa([1,3,4]),etc
  x = 1*(t>=0)  % returneaza 1 daca relatia este adevarata si 0
                % daca relatia este falsa