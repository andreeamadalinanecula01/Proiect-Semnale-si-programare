%exemplu folosire a instructiunilor audio.m
clear all; clf 
%%==============generarea unui semnal audio=========
Fs=5000;%frecventa de esantionare.inversul pasului pentru generarea vectorului de tip timp
t=0:1/Fs:2;%generarea vectorului de tip timp
F_Fa=349;
y=sin(2*pi*F_Fa*t);%generarea semnalului audio

audiowrite("fa.wav",y, Fs)%functie care genereaza un fisier audio

[y1, Fs1]=audioread("fa.wav");%citirea unui fisier audio si extragerea 
                                 %parametrilor,semnal si frecventa de esantionare

sound(y1, Fs1)%sunetul generat de parametrii extrasi dupa citirea fisierului audio

figure(1)
plot(t(1:1000), y1(1:1000))
xlabel('Timp(s)', "Fontsize", 30);
ylabel('Amplitudine', "Fontsize", 30);
