clear all;
pkg load symbolic 
%=============================

syms t x z; %definirea variabilelor ca simboluri

x=sin(t)/t;%semnal cosinus variabil simbolic
z=int(x^2); %calculul integralei;

figure(1) %generare figura noua 
subplot(211) %generarea unei subfiguri
ezplot(x^2,[0,6*pi]);grid %graficul functiei simbolice intre 0si 2*pi

hold on 
subplot(212) %generarea unei subfiguri
ezplot(z,[0,6*pi]);grid %graficul functiei simbolice intre 0si 2*pi
hold off

